<?php
session_start();

if(session_destroy()){
    $_SESSION = array();
    $newURL = "http://localhost/iota-bootstrap5/";
    // $newURL = "http://iot-a.mn";
    header('Location: '.$newURL);
}