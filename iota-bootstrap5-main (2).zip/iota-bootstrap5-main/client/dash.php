<?php

session_start();

if ($_SESSION['username'] == null || $_SESSION['username'] == "") {
    if (session_destroy()) {
        $newURL = "http://localhost/iota-bootstrap5/";
        header('Location: '.$newURL);
    }
}
include 'layout/html_header.php';
include 'layout/html_menu.php';
?>


        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

            <?php
            include 'layout/html_topbar.php';
            ?>
            <div id="main-content">
                <?php
                    include 'layout/html_content1.php';
                ?>
            </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Бүх эрх хуулиар хамгаалагдсан &copy; Иот-а.мн 2022</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script>

        function draw(id){
            switch (id) {
                case 'monitor':
                    console.log(id);
                    break;
                case 'report':
                    console.log(id);
                    break;
                case 'adddev':
                    console.log(id);
                    break;
                case 'setdev':
                    console.log(id);
                    break;
            
                default:
                    console.log(id);
                    break;
            }
            $.ajax({
                type: "POST",
                url: '../functions/draw.php',
                // url: 'html_content1.php',
                data: {"cmd" : "dash", "cmmd" : id},
                success: function(response)
                {
                    // document.getElementById("main-content").innerHTML = response;
                    $("#main-content").html(response);
                }
            });

            if(id == 'monitor'){
                sleep(3000).then(() => { refreshContent(); });
            }
            // if(id == 'adddev'){
            //     adddev();
            // }
            
        }
    // const someFile = require("js/demo/chart-area-demo.js");
    // import {A} from 'js/demo/chart-area-demo.js';
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
    </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    function reload_js(src) {
        $('script[src="' + src + '"]').remove();
        $('<script>').attr('src', src).appendTo('#main-content');
    }
</script>



    <?php
    include 'layout/html_footer.php';
    ?>