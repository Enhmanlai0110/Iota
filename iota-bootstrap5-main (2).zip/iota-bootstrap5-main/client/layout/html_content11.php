<!-- Begin Page Content -->
<div class="container-fluid" style='margin-bottom: 80px'>
<style>
    .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
    }

    .switch input { 
    opacity: 0;
    width: 0;
    height: 0;
    }

    .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
    }

    .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
    }

    input:checked + .slider {
    background-color: #2196F3;
    }

    input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
    border-radius: 34px;
    }

    .slider.round:before {
    border-radius: 100%;
    }
    </style>
            
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Төхөөрөмжийн хүсэлтүүд</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="myAreaChart"></canvas>
                    </div>
                    <hr>
                    <!-- Төхөөрөмжүүдийн хүсэлт явуулсан байдал. -->
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="row">
        <!-- Donut Chart -->
        <?php
        for ($i=0; $i < 5; $i++) {                      
        ?>
        <div class="col-xl-4 col-lg-6">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary" id='dev<?=$i?>' onclick='setname(this);'>Төхөөрөмжийн нэр</h6>
                    <input type="text" id='sdev<?=$i?>' onfocusout='setcname(this);' onchange='setcname(this);' style='display: none' placeholder="ner">
                </div>
                <!-- Card Body -->
                <div class="card-body" style='text-align: center;'>
                    
                    <div class="row">
                        <div class="col-sm">
                        18C
                        </div>
                        <div class="col-sm">
                        
                        <label class="switch">
                            <input type="checkbox" checked onchange='keyswitch(this);'>
                            <span class="slider round"></span>
                        </label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm">
                        55%
                        </div>
                        <div class="col-sm">

                        <label class="switch">
                            <input type="checkbox" checked onchange='keyswitch(this);'>
                            <span class="slider round"></span>
                        </label>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-sm">
                        20220925 17:30
                        </div>
                        <div class="col-sm">
                        <label class="switch">
                            <input type="checkbox" checked onchange='keyswitch(this);'>
                            <span class="slider round"></span>
                        </label>
                        </div>
                    </div>

                    <hr>
                    <!-- Styling for the donut chart can be found in the
                    <code>/js/demo/chart-pie-demo.js</code> file. -->
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>

    
    <!-- Page level plugins -->
    <script>
        function setname(e){
            // console.log(e.id);
            e.style.display = "none";
            document.getElementById('s'+e.id).style.display = "inline-block";
            document.getElementById('s'+e.id).placeholder = e.innerText;
        }
        function setcname(e){
            // console.log(e.id);
            e.style.display = "none";
            document.getElementById(e.id.substring(1)).style.display = "inline-block";
            if(!e.value){
                document.getElementById(e.id.substring(1)).innerText = "Төхөөрөмжийн нэр";
            }else{
                document.getElementById(e.id.substring(1)).innerText = e.value;
            }
        }

        function keyswitch(e){
            reload_js('vendor/chart.js/Chart.min.js');
            reload_js('js/demo/chart-area-demo.js');
            console.log(e);
        }
    </script>
    
</div>
    <!-- /.container-fluid -->