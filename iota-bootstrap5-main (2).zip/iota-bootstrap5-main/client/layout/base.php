<?php
/*
create by Sukhbold.b for IOT-A
20220901
*/

function create_user(){
    $sql_smart_users = "
        CREATE TABLE smart_users (
            userid int NOT NULL AUTO_INCREMENT,
            username varchar(50) NOT NULL UNIQUE,
            userpass varchar(50) NOT NULL,
            lname varchar(50) NOT NULL,
            fname varchar(50) NOT NULL,
            phone varchar(50) NOT NULL UNIQUE,
            email varchar(50) NOT NULL UNIQUE,
            sex int(1),
            PRIMARY KEY (userid)
        )
    ";
}
function get_records($conn, $sql){
    $array = array();
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each rowP
        while($row = $result->fetch_assoc()) {
            $array[] = $row; 
        }
    } else {
        return $array;
    }
    return $array;
}
function get_record($conn, $sql){
    $array = array();
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each rowP
        while($row = $result->fetch_assoc()) {
            $array = $row; 
        }
    } else {
        return $array;
    }
    return $array;
}

// $servername = "host53.registrar-servers.com";
// $username = "iotamn_admin";
// $password = "Iotamn#123";
// $dbname = "iotamn_iotamn";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iotamn";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


