<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'base.php';
$userid = $_SESSION['userid'];
$sql = "SELECT * from smart_user_dev a 
        left join smart_dev b on b.devtoken = a.devtoken
        where a.userid = '$userid' and a.status = 1";

$res = get_records($conn, $sql);
?>

<!-- Begin Page Content -->
<div class="container-fluid" style='margin-bottom: 80px'>
<style>
    .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
    }

    .switch input { 
    opacity: 0;
    width: 0;
    height: 0;
    }

    .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
    }

    .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
    }

    input:checked + .slider {
    background-color: #2196F3;
    }

    input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
    border-radius: 34px;
    }

    .slider.round:before {
    border-radius: 100%;
    }
    </style>
            
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Төхөөрөмжийн хүсэлтүүд</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="myAreaChart"></canvas>
                    </div>
                    <hr>
                    <!-- Төхөөрөмжүүдийн хүсэлт явуулсан байдал. -->
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="row">
        <!-- Donut Chart -->
        <?php
        foreach ($res as $key => $value) {                      
        ?>
        <div class="col-xl-4 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary" id='dev<?=$key?>' onclick='setname(this);'><?= $value['devname'] ? $value['devname'] : $value['devtoken']?></h6>
                    <input type="text" id='sdev<?=$key?>' onfocusout="setcname(this,'<?=$value['devtoken']?>',1);" onchange="setcname(this,'<?=$value['devtoken']?>',0);" style='display: none' placeholder="ner">
                </div>
                <div class="card-body" style='text-align: center;'>
                    <div class="row">
                        <div class="col-sm-4">
                        <?=$value['temp']?><sup>o</sup>C<br><?=$value['hum']?>%<br><?=$value['createdate']?><br><?=$value['lastconn']?>
                        </div>
                        <div class="col-sm">
                            <div class="row-sm-12">
                                <label class="switch">
                                    <input type="checkbox" id="<?=$value['devtoken']?>k1" <?=$value['k1'] ? "checked" : "" ?> onchange='keyswitch(this);'>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                            <div class="row-sm-12">
                                <label class="switch">
                                    <input type="checkbox" id="<?=$value['devtoken']?>k2" <?=$value['k2'] ? "checked" : "" ?> onchange='keyswitch(this);'>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                            <div class="row-sm-12">
                                <label class="switch">
                                    <input type="checkbox" id="<?=$value['devtoken']?>k3" <?=$value['k3'] ? "checked" : "" ?> onchange='keyswitch(this);'>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>

    
    <!-- Page level plugins -->
    <script>
        function setname(e){
            // console.log(e.id);
            e.style.display = "none";
            document.getElementById('s'+e.id).style.display = "inline-block";
            document.getElementById('s'+e.id).placeholder = e.innerText;
        }
        function setcname(e,id,stt){
            console.log(e.id);
            console.log(id);
            e.style.display = "none";
            document.getElementById(e.id.substring(1)).style.display = "inline-block";
            if(e.value){
                document.getElementById(e.id.substring(1)).innerText = e.value;
                if(stt){
                    id1 = document.getElementById(id + 'k1').checked ? 1 : 0;
                    id2 = document.getElementById(id + 'k2').checked ? 1 : 0;
                    id3 = document.getElementById(id + 'k3').checked ? 1 : 0;
                    $.ajax({
                        type: "POST",
                        url: '../functions/functions.php',
                        // url: 'html_content1.php',
                        data: {"cmd" : "updatedev", "name" : e.value, "id" : id, "k1" : id1, "k2" : id2, "k3" : id3},
                        success: function(response)
                        {
                            var jsonData = JSON.parse(response);
                            if (jsonData.success == "1")
                            {
                                console.log('Success Credentials!');
                                console.log(jsonData.req);
                                alert(jsonData.msg);
                            }
                            else
                            {
                                console.log(jsonData.req);
                                alert(jsonData.msg);
                            }
                        }
                    });
                }
            }
        }

        function keyswitch(e){
            var key = e.id.slice(-2);
            var id = e.id.slice(0,-2);
            var val = e.checked ? 1 : 0;
            // console.log(id);
            // console.log(key);
            // console.log(e.checked ? 1 : 0);
            $.ajax({
                type: "POST",
                url: '../functions/functions.php',
                // url: 'html_content1.php',
                data: {"cmd" : "updatedevkey", "id" : id, "key" : key, "val" : val},
                success: function(response)
                {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        console.log('Success Credentials!');
                        // console.log(jsonData.req);
                        alert(jsonData.msg);
                        // setTimeout(function() { alert(jsonData.msg); }, 1500);
                    }
                    else
                    {
                        // console.log(jsonData.req);
                        // console.log(jsonData.sql);
                        alert(jsonData.msg);
                        // setTimeout(function() { alert(jsonData.msg); }, 1500);
                        e.checked = !val;
                    }
                }
            });
        }

        function refreshContent(){
            reload_js('vendor/chart.js/Chart.min.js');
            reload_js('js/demo/chart-area-demo.js');
        }
    </script>    
</div>
    <!-- /.container-fluid -->