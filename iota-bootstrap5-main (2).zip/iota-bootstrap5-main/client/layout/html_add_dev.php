<?php
session_start();


if($_SESSION['isadmin'] == 0)
{
?>

<div class="container-fluid" style='margin-bottom: 80px'>  
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Төхөөрөмж нэмэх</h6>
                </div>
                <div class="card-body">
                    
                <form class="form-inline">
                    <div class="form-group mb-2">
                        <label for="dev" class="sr-only">Төхөөрөмжийн токен : </label>
                        <input type="text" readonly class="form-control-plaintext" id="dev" value="Төхөөрөмжийн токен : ">
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="token" class="sr-only">dev#654AF564$123</label>
                        <input type="text" class="form-control" id="token" placeholder="dev#654AF564$123">
                    </div>
                    <a href="#" class="btn btn-primary mb-2" onclick="adddev(document.getElementById('token'));">Бүртгэх</a>
                </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Бүртгэлтэй төхөөрөмжүүд</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Хэрэглэгч</th>
                                    <th>Төхөөрөмж</th>
                                    <th>Статус</th>
                                    <th>Бүртгэсэн огноо</th>
                                    <th>Сүүлд холбогдсон огноо</th>
                                    <th>Үйлдэл</th>
                                </tr>
                            </thead>
                            <tbody id = "tabledata">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
        function adddev(token){
            console.log(token.value);
            $.ajax({
                type: "POST",
                url: '../functions/functions.php',
                data: {"cmd" : 'adddev', 'token' : token.value},
                success: function(response)
                {
                    // console.log(response);
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        console.log('Success Credentials!');
                        tabledata();
                        alert(jsonData.msg);
                    }
                    else
                    {
                        alert(jsonData.msg);
                    }
                }
            });
        }
        function tabledata(){
            $.ajax({
                type: "POST",
                url: '../functions/functions.php',
                data: {"cmd" : 'tabledata'},
                success: function(response)
                {
                    console.log(response); 
                    $("#tabledata").html(response);
                    // var jsonData = JSON.parse(response);
                    // if (jsonData.success == "1")
                    // {
                    //     console.log('Success Credentials!');
                    //     alert(jsonData.msg);
                    // }
                    // else
                    // {
                    //     alert(jsonData.msg);
                    // }
                }
            });
        }
        
        tabledata();

</script>
<?php
}else{
    ?>
  <div class="container-fluid" style='margin-bottom: 80px'>  
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Төхөөрөмж нэмэх</h6>
                </div>
                <div class="card-body">
                    
                <form class="form-inline">
                    <div class="form-group mb-2">
                        <label for="dev" class="sr-only">Төхөөрөмжийн токен : </label>
                        <input type="text" readonly class="form-control-plaintext" id="dev" value="Төхөөрөмжийн токен : ">
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="token" class="sr-only">dev#654AF564$123</label>
                        <input type="text" class="form-control" id="token" placeholder="dev#654AF564$123">
                    </div>
                    <a href="#" class="btn btn-primary mb-2" onclick="AdminAddDev(document.getElementById('token'));">Бүртгэх</a>
                </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Бүртгэлтэй төхөөрөмжүүд</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Хэрэглэгч</th>
                                    <th>Төхөөрөмж</th>
                                    <th>Статус</th>
                                    <th>Бүртгэсэн огноо</th>
                                    <th>Сүүлд холбогдсон огноо</th>
                                    <th>Үйлдэл</th>
                                </tr>
                            </thead>
                            <tbody id = "AdminDataTable">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
        function AdminAddDev(token){
            console.log(token.value);
            $.ajax({
                type: "POST",
                url: '../functions/functions.php',
                data: {"cmd" : 'AdminAddDev', 'token' : token.value},
                success: function(response)
                {
                    // console.log(response);
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        console.log('Success Credentials!');
                        tabledata1();
                        alert(jsonData.msg);
                    }
                    else
                    {
                        alert(jsonData.msg);
                    }
                }
            });
        }
        function AdminDataTable(){
            $.ajax({
                type: "POST",
                url: '../functions/functions.php',
                data: {"cmd" : 'AdminDataTable'},
                success: function(response)
                {
                    console.log(response); 
                    $("#AdminDataTable").html(response);
                }
            });
        }
        AdminDataTable();
</script>
<?php
}
?>
