<?php
/*
create by Sukhbold.b for IOT-A
20220901
*/
session_start();
header('Location: dash.php');