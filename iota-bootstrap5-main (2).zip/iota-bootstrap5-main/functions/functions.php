<?php
/*
create by Sukhbold.b for IOT-A
20220901
*/
session_start();
include 'base.php';

$cmd = $_REQUEST['cmd'];

switch ($cmd) {
    case 'login':
        login();
        break;
    case 'getsigned':
        newcustomer();
        break;
    case 'adddev':
        adddev();
        break;
    case 'tabledata':
        tabledata();
        break;
    case 'updatedev':
        updatedev(0);
        break;
    case 'updatedevkey':
        updatedev(1);
        break;
    case 'AdminAddDev':
        AdminAddDev();
        break;
    case 'AdminDataTable';
    AdminDataTable();
        break;
    default:
        # code...
        break;
};

function login(){
    global $conn;
    $username = $_REQUEST['username'];
    $userpass = $_REQUEST['password'];
    $sql = "SELECT * from smart_users a WHERE a.username = '$username' and a.userpass = '$userpass'";
    $res = get_record($conn, $sql);
    if(sizeof($res) > 0){
        $arr = array('success' => 1, 'username' => $username, "password" => $userpass, "sql" => $sql, "res" => $res);
        $_SESSION['username'] = $username;
        $_SESSION['userid'] = $res['userid'];
        $_SESSION['isadmin'] = $res['isadmin'];
    }else{
        $arr = array('success' => 0, 'username' => $username, "password" => $userpass, "sql" => $sql, "res" => $res);
    }
    echo json_encode($arr);
};
function newcustomer(){
    global $conn;

    $username = $_REQUEST['username'];
    $password = $_REQUEST['password'];
    $fname = $_REQUEST['fname'];
    $lname = $_REQUEST['lname'];
    $phone = $_REQUEST['phone'];
    $email = $_REQUEST['email'];
    $sex = $_REQUEST['sex'];


    $sql = "INSERT INTO smart_users (
        username
        ,userpass
        ,lname
        ,fname
        ,phone
        ,email
        ,sex
        ,createdate
        ,isadmin
        ,status
        ) 
        VALUES (
        '$username'
        ,'$password'
        ,'$lname'
        ,'$fname'
        ,'$phone'
        ,'$email'
        ,'$sex'
        , NOW()
        , 0
        , 1
        )";
    // $arr = array('success' => 0, 'res' => $conn->error);

    try {
        if ($conn->query($sql) === TRUE) {
            $arr = array('success' => 1);
        } else {
            $arr = array('success' => 0);
        }
    }
    catch(Exception $e) {
        $arr = array('success' => 0);
    }
    

    echo json_encode($arr);
};
function adddev(){
    global $conn;
    $token = $_REQUEST['token'];
    $userid = $_SESSION['userid'];

    if(!$token || !$userid){
        $arr = array('success' => 0, 'msg' => 'Токен хоосон байна');
    }
    else{
        $sql = "SELECT count(*) cnt FROM smart_dev a where a.devtoken = '$token'";
        $res = get_record($conn, $sql);
        if($res['cnt'] != 0){
            $sql = "SELECT count(*) cnt FROM smart_user_dev a where a.devtoken = '$token' AND a.status='1'";
            $res = get_record($conn, $sql);
            if($res['cnt'] == 0){
                $sql = "INSERT INTO smart_user_dev (
                        userid
                        ,devtoken
                        ,status
                        ,createdate
                        ) 
                        VALUES (
                        '$userid'
                        ,'$token'
                        , 1
                        , NOW()
                        )";
                
                    try {
                        if ($conn->query($sql) === TRUE) {
                            $arr = array('success' => 1, 'msg' => 'Төхөөрөмж амжилттай нэмэгдсэн');
                        } else {
                            $arr = array('success' => 0, 'msg' => 'Алдаа нэмэх боломжгүй');
                        }
                    }
                    catch(Exception $e) {
                        $arr = array('success' => 0, 'msg' => 'Алдаа');
                    }
            }else{
                $arr = array('success' => 0, 'msg' => 'Аль хэдийн холбогдсон төхөөрөмж байна');
            }   
        }else{
            $arr = array('success' => 0, 'msg' => 'Төхөөрөмж хараахан идэвхижээгүй байна');
        }
        // $arr = array('success' => 1, 'req' => $_REQUEST, 'sql' => $sql, 'cnt' => $res['cnt']);
    }
    echo json_encode($arr);
};
function AdminAddDev(){
    global $conn;
    $token = $_REQUEST['token'];

    $sql = "INSERT INTO smart_dev (
            devtoken
            ,k1
            ,k2
            ,k3
            ,temp
            ,hum
            ,mo
            ,status
            ,createdate
            ) 
            VALUES (
            '$token'
            , 0
            , 0
            , 0
            , 0
            , 0
            , 0
            , 1
            , NOW()
            )";
        try {
            if ($conn->query($sql) === TRUE) {
                $arr = array('success' => 1, 'msg' => 'Төхөөрөмж амжилттай нэмэгдсэн');
            } else {
                $arr = array('success' => 0, 'msg' => 'Алдаа нэмэх боломжгүй');
            }
        }
        catch(Exception $e) {
            $arr = array('success' => 0, 'msg' => 'Алдаа');
        }
        echo json_encode($arr);
};

function tabledata(){
    global $conn;
    $userid = $_SESSION['userid'];

    $sql = "SELECT * FROM smart_user_dev a where a.userid = '$userid' AND a.status='1'";
    $res = get_records($conn, $sql);
    // print_r($res);
    $i = 0;
    foreach ($res as $key => $value) {
        ?>
            <tr>
                <td><?=++$i?></td>
                <td><?=$value['userid']?></td>
                <td><?=$value['devtoken']?></td>
                <td><?=$value['status']?></td>
                <td><?=$value['createdate']?></td>
                <td><?=$value['createdate']?></td>
                <td><a href="#" class="btn btn-danger mb-2 w-100" onclick="edit('<?=$value['devtoken']?>');">edit</a></td>
            </tr>
        <?php
    }
};

function AdminDataTable(){
    global $conn;
    $sql = "SELECT a.devid, a.devtoken, a.createdate as devdate, a.lastconn, b.userid, b.status, b.createdate as userdate FROM smart_dev a left join smart_user_dev b on a.devtoken = b.devtoken";
    $res = get_records($conn, $sql);
    $i = 0;
    foreach ($res as $key => $value) {
       ?>
           <tr>
               <td><?=++$i?></td>
               <td><?=$value['devid']?></td>
               <td><?=$value['devtoken']?></td>
               <td><?=$value['userid']?></td>
               <td><?=$value['status']?></td>
               <td><?=$value['devdate']?></td>
               <td><?=$value['userdate']?></td>
               <td><?=$value['lastconn']?></td>
               <td><a href="#" class="btn btn-danger mb-2 w-100" onclick="edit('<?=$value['devtoken']?>');">edit</a></td>
           </tr>
       <?php
    }
};

function updatedev($flag){
    global $conn;

    switch ($flag) {
        case 0:
            $devtoken = $_REQUEST['id'];
            $name = $_REQUEST['name'];
            $k1 = $_REQUEST['k1'];
            $k2 = $_REQUEST['k2'];
            $k3 = $_REQUEST['k3'];
            $sql = "update smart_dev set devname = '$name', k1 = $k1, k2 = $k2, k3 = $k3 where devtoken = '$devtoken'";
            break;
        case 1:
            $devtoken = $_REQUEST['id'];
            $key = $_REQUEST['key'];
            $val = $_REQUEST['val'];
            $sql = "update smart_dev set $key = $val where devtoken = '$devtoken'";
            break;
        
        default:
            # code...
            break;
    }

    try {
        if ($conn->query($sql) === TRUE) {
            $arr = array('success' => 1, 'msg' => 'Амжилттай');
        } else {
            $arr = array('success' => 0, 'msg' => 'Амжилтгүй', 'req' => $_REQUEST, 'sql' => $sql);
        }
    }
    catch(Exception $e) {
        $arr = array('success' => 0, 'msg' => 'Алдаа');
    }
    echo json_encode($arr);
};
?>
