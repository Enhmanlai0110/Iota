<?php
/*
create by Sukhbold.b for IOT-A
20220901
*/

$cmd = $_REQUEST['cmd'];

switch ($cmd) {
    case 'login':
        login();
        break;
    case 'info':
        info();
        break;
    case 'signup':
        signup();
        break;
    case 'reset1':
        reset1();
        break;
    case 'cont':
        cont();
        break;
    case 'send':
        send();
        break;
    case 'dash':
        switch ($_REQUEST['cmmd']) {
            case 'monitor':
                dash_monitor();
                break;
            case 'report':
                dash_report();
                break;
            case 'adddev':
                dash_adddev();
                break;
            case 'setdev':
                dash_setdev();
                break;
            
            default:
                # code...
                break;
        }
        break;
    default:
        # code...
        break;
};

function login(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='p-5'>
                                <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>Нэвтрэх</h1>
                                </div>
                                <form class='user'>
                                    <div class='form-group'>
                                        <input id='username' type='email' class='form-control form-control-user'
                                            id='exampleInputEmail' aria-describedby='emailHelp'
                                            placeholder='Нэвтрэх нэрээ оруулна уу...'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='password' type='password' class='form-control form-control-user'
                                            id='exampleInputPassword' placeholder='Нууц үг'>
                                    </div>
                                    <a href='#' id='btnloginform' class='btn btn-primary btn-user btn-block'  onclick='login(this.id);'>
                                        Нэвтрэх
                                    </a>
                                    <hr>
                                </form>
                                <div class='text-center'>
                                    <a id='reset' onclick='reset1(this.id);' class='small' href='#'>Нууц үгээ мартсан уу?</a>
                                </div>
                                <div class='text-center'>
                                    <a id='register' onclick='signup(this.id);' class='small' href='#'>Шинээр бүртгүүлэх!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
};
function signup(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='p-5'>
                                <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>Бүртгүүлэх</h1>
                                </div>
                                <form class='user'>
                                    <div class='form-group'>
                                        <input id='username' type='text' class='form-control form-control-user'
                                            id='exampleInputEmail' aria-describedby='emailHelp'
                                            placeholder='Нэвтрэх нэрээ оруулна уу...'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='lname' type='text' class='form-control form-control-user'
                                            placeholder='Овог'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='fname' type='text' class='form-control form-control-user'
                                            placeholder='Нэр'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='password' type='password' class='form-control form-control-user'
                                            id='exampleInputPassword' placeholder='Нэвтрэх нууц үг...'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='password1' type='password' class='form-control form-control-user'
                                            id='exampleInputPassword' placeholder='Нууц үг давтан оруулна уу...'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='email' type='email' class='form-control form-control-user'
                                            id='exampleInputemail' placeholder='Email оруулна уу...'>
                                    </div>
                                    <div class='form-group'>
                                        <input id='phone' type='phone' class='form-control form-control-user'
                                            id='exampleInputPhone' placeholder='Утасны дугаараа оруулна уу...'>
                                    </div>
                                    
                                    <div class='form-group' hidden>
                                        <select id='sex' class='form-control form-control-user'>
                                            <option value='0' >Эмэгтэй</option>
                                            <option value='1' >Эрэгтэй</option>
                                        </select>
                                    </div>

                                    <a href='#' id='getsigned' class='btn btn-primary btn-user btn-block'  onclick='newcustomer(this.id);'>
                                        Шинэ хэрэглэгч болох
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
}
function reset1(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='p-5'>
                                <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>Нууц үг шинэчлэх</h1>
                                </div>
                                <form class='user'>
                                    <div class='form-group'>
                                        <input id='username' type='email' class='form-control form-control-user'
                                            id='exampleInputEmail' aria-describedby='emailHelp'
                                            placeholder='Нэвтрэх нэрээ оруулна уу...'>
                                    </div>
                                    </div>
                                    <a href='#' id='cont' class='btn btn-primary btn-user btn-block'  onclick='cont(this.id);'>
                                        Үргэлжлүүлэх
                                    </a>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
}
function cont(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='p-5'>
                                <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>Нууц үг шинэчлэх</h1>
                                </div>
                                <form class='user'>
                                    <div class='form-group'>
                                        <input id='username' type='email' class='form-control form-control-user'
                                            id='exampleInputEmail' aria-describedby='emailHelp'
                                            placeholder='Бүртгэлтэй Email оруулна уу'>
                                    </div>
                                    </div>
                                    <a href='#' id='send' class='btn btn-primary btn-user btn-block'  onclick='send(this.id);'>
                                        Код илгээх
                                    </a>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
}
function send(){
$html = "
<div class='container' id='loginform'>
    <div class='row justify-content-center'>
        <div class='col-xl-6 col-lg-6 col-md-6'>
            <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                <div class='card-body p-0'>
                    <div>
                        <div class='p-5'>
                            <div class='text-center'>
                                <h1 class='h4 text-gray-900 mb-4'>Нууц үг шинэчлэх</h1>
                            </div>
                            <form class='user'>
                                <div class='form-group'>
                                    <input id='username' type='email' class='form-control form-control-user'
                                        id='exampleInputEmail' aria-describedby='emailHelp'
                                        placeholder='Илгээсэн кодыг оруулна уу'>
                                </div>
                                </div>
                                <a href='#' id='done' class='btn btn-primary btn-user btn-block'  onclick='done(this.id);'>
                                    Болсон
                                </a>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
";
$arr = array('success' => 1, 'html' => $html);
echo json_encode($arr);
}


function info(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>hello</h1>
                                </div>
                            <h1>hello</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
};
function whatis(){
    $html = "
    <div class='container' id='loginform'>
        <div class='row justify-content-center'>
            <div class='col-xl-6 col-lg-6 col-md-6'>
                <div class='card o-hidden border-0 shadow-lg my-5 bg-light-85'>
                    <div class='card-body p-0'>
                        <div>
                            <div class='text-center'>
                                    <h1 class='h4 text-gray-900 mb-4'>hello</h1>
                                </div>
                            <h1>hello</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    ";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
};

function dash_monitor(){
    $URL = '../client/layout/html_content1.php';
    // include '../client/html_content1.php';
    // $URL = '../client/dash.php';
    header('Location: '.$URL);
    exit;
}
function dash_report(){
    $html = "";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
}
function dash_adddev(){
    $URL = '../client/layout/html_add_dev.php';
    header('Location: '.$URL);
    exit;
}
function dash_setdev(){
    $html = "";
    $arr = array('success' => 1, 'html' => $html);
    echo json_encode($arr);
}
?>
