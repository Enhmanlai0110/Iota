<?php
include 'base.php';

$cmd = $_REQUEST['cmd'];

switch ($cmd) {
    case 'incomedev':
        incomedev();
        break;
    
    default:
        # code...
        break;
}

function incomedev(){
    global $conn;
    $devtoken = $_REQUEST['id'];

    $sql = "SELECT * from smart_dev where devtoken = '$devtoken'";
    $res = get_record($conn, $sql);
    if(sizeof($res) > 0){
        $arr = array('success' => 1, 'k1' => $res['k1'], 'k2' => $res['k2'], 'k3' => $res['k3']);   
    }else{
        $arr = array('success' => 0);
    }
    echo json_encode($arr);
}