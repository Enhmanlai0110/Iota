<?php
/*
create by Sukhbold.b for IOT-A
20220901
*/

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=no,user-scalable=0"/>
    <title>Иот-а.мн</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="client/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- <link href="client/css/custom.css" rel="stylesheet"> -->
    <link href="client/css/sb-admin-2.css" rel="stylesheet">
    <script type="text/javascript" src="client/js/nodes.js"></script>
    <script type="text/javascript">
        let width = window.innerWidth;
        let height = $(window).height();
        console.log(width);
        console.log(height);
        console.log(window.innerHeight);
        var nodesjs = new NodesJs({
            id: 'nodes',
            width: width,
            height: height,
            particleSize: 2,
            lineSize: 1,
            particleColor: [255, 255, 255, 0.3],
            lineColor: [255, 255, 255],
            backgroundFrom: [0, 0, 0],
            backgroundTo: [0, 20, 40],
            backgroundDuration: 20000,
            nobg: false,
            number: window.hasOwnProperty('orientation') ? 10: 100,
            speed: 20
        });
        window.onresize = function () {
            nodesjs.setWidth(window.innerWidth);
            nodesjs.setHeight(window.innerHeight);
        };
    </script>
</head>
<body>
    
    <div style="position: absolute; left: 0px; top: 0px; overflow: hidden; width: 100%; height: 100%;">
        <canvas id="nodes"></canvas>
    </div>    


    <nav class="navbar navbar-expand-lg navbar-light bg-light-85">
    <div class="col-md-2"></div>
        <div class="container-fluid col-md-1">
                <a class="navbar-brand" href="#">
                    <img src="files/png/BIGOUT-300x300.png" alt="" width="80" height="80" class="d-inline-block align-text-top">
                </a>
        </div>
        <div class="container-fluid col-md-6">
            <div class="collapse navbar-collapse" id="navbarSupportedContent" >
                <ul class="navbar-nav me-auto mb-2 mb-lg-0"  style="float: none; margin: 0 auto;">
                    <li class="nav-item">
                    <a class="nav-link" href="#" style="font-size: 1.2rem;">Танилцуулга</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="#" id="whatis" onclick="whatis(this.id);" style="font-size: 1.2rem;">IoT гэж юу вэ?</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true" style="font-size: 1.2rem;">Төслүүд</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="container-fluid col-md-1">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="#" id="btnlogin" onclick="login(this.id);" style="font-size: 1.2rem;">Нэвтрэх</a>
                </li>
            </ul>
        </div>
    <div class="col-md-2"></div>
    </nav>
    
    <div id = "resp">
    </div>

    <!-- <div class="wrapper">
        <ul class="loader-list"> -->
            <!-- <li>
                <div class="loader-1 center"><span></span></div>
            </li>
            <li>
                <div class="loader-2 center"><span></span></div>
            </li>
            <li>
                <div class="loader-3 center"><span></span></div>
            </li>
            <li>
                <div class="loader-4 center"><span></span></div>
            </li> -->
            <!-- <li> -->
                <!-- <div class="loader-5 center"><span></span></div> -->
            <!-- </li> -->
            <!-- <li>
                <div class="loader-6 center"><span></span></div>
            </li> -->
        <!-- </ul>
    </div> -->

</body>
<script>
    function newcustomer(id){
        console.log(id);
        if(id == 'getsigned'){
            
            let username = (document.getElementById("username").value);
            let password = (document.getElementById("password").value);
            let password1 = (document.getElementById("password1").value);
            let fname = (document.getElementById("fname").value);
            let lname = (document.getElementById("lname").value);
            let phone = (document.getElementById("phone").value);
            let email = (document.getElementById("email").value);
            let sex = (document.getElementById("sex").value);

            if(password != password1){
                alert("Оруулсан нууц үг таарахгүй байна! дахин оруулна уу!");
            }else{
                if(
                    username == "" || username == null ||
                    password == "" || password == null ||
                    password1 == "" || password1 == null ||
                    fname == "" || fname == null ||
                    lname == "" || lname == null ||
                    phone == "" || phone == null ||
                    email == "" || email == null 
                ){
                    alert("Мэдээлэл дутуу оруулсан тул дахин оруулна уу!");
                }else{                    
                    $.ajax({
                        type: "POST",
                        url: 'functions/functions.php',
                        data: {"cmd" : "getsigned"
                                ,"username" : username
                                ,"password" : password
                                ,"password1" : password1
                                ,"fname" : fname
                                ,"lname" : lname
                                ,"phone" : phone
                                ,"email" : email
                                ,"sex" : sex
                        },
                        success: function(response)
                        {
                            var jsonData = JSON.parse(response);
                            if (jsonData.success == "1")
                            {
                                alert("Амжилттай бүртгэж авлаа");
                                login("btnlogin");
                            }
                            else
                            {
                                alert("Мэдээлэл давахцаж байгаа тул бүртгэл амжилтгүй");
                            }
                        }
                    });     
                }
            } 
        }else if (id == 'newcustomer'){
            document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
            $.ajax({
                type: "POST",
                url: 'functions/draw.php',
                data: {"cmd" : "newcustomer"},
                success: function(response)
                {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        // location.href = 'my_profile.php';
                        console.log('Success Credentials!');
                        document.getElementById("resp").innerHTML = jsonData.html;
                        // $('#resp') = jsonData.html;
                    }
                    else
                    {
                        console.log('Invalid Credentials!');
                    }
                }
            });   
        }
    }
    function send(id){
        console.log(id);
        console.log("send");
        document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
        $.ajax({
            type: "POST",
            url: 'functions/draw.php',
            data: {"cmd" : "send"},
            success: function(response)
            {
                var jsonData = JSON.parse(response);
                if (jsonData.success == "1")
                {
                    // location.href = 'my_profile.php';
                    console.log('Success Credentials!');
                    document.getElementById("resp").innerHTML = jsonData.html;
                    // $('#resp') = jsonData.html;
                }
                else
                {
                    console.log('Invalid Credentials!');
                }
            }
        });
    }
    function cont(id){
        console.log(id);
        console.log("cont");
        document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
        $.ajax({
            type: "POST",
            url: 'functions/draw.php',
            data: {"cmd" : "cont"},
            success: function(response)
            {
                var jsonData = JSON.parse(response);
                if (jsonData.success == "1")
                {
                    // location.href = 'my_profile.php';
                    console.log('Success Credentials!');
                    document.getElementById("resp").innerHTML = jsonData.html;
                    // $('#resp') = jsonData.html;
                }
                else
                {
                    console.log('Invalid Credentials!');
                }
            }
        });
    }
    function reset1(id){
        console.log(id);
        console.log("reset1");
        document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
        $.ajax({
            type: "POST",
            url: 'functions/draw.php',
            data: {"cmd" : "reset1"},
            success: function(response)
            {
                var jsonData = JSON.parse(response);
                if (jsonData.success == "1")
                {
                    // location.href = 'my_profile.php';
                    console.log('Success Credentials!');
                    document.getElementById("resp").innerHTML = jsonData.html;
                    // $('#resp') = jsonData.html;
                }
                else
                {
                    console.log('Invalid Credentials!');
                }
            }
        });
    }
    function signup(id){
        console.log(id);
        console.log("signup");
        document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
        $.ajax({
            type: "POST",
            url: 'functions/draw.php',
            data: {"cmd" : "signup"},
            success: function(response)
            {
                var jsonData = JSON.parse(response);
                if (jsonData.success == "1")
                {
                    // location.href = 'my_profile.php';
                    console.log('Success Credentials!');
                    document.getElementById("resp").innerHTML = jsonData.html;
                    // $('#resp') = jsonData.html;
                }
                else
                {
                    console.log('Invalid Credentials!');
                }
            }
        });
    }
    function login(id){
        console.log("Login");
        console.log(id);
        if(id == "btnlogin"){
            document.getElementById("resp").innerHTML = "<div class='loader-5 center'><span></span></div>";
            $.ajax({
                type: "POST",
                url: 'functions/draw.php',
                data: {"cmd" : "login"},
                success: function(response)
                {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        // location.href = 'my_profile.php';
                        console.log('Success Credentials!');
                        document.getElementById("resp").innerHTML = jsonData.html;
                        // $('#resp') = jsonData.html;
                    }
                    else
                    {
                        console.log('Invalid Credentials!');
                    }
                }
            });
        }else if(id == "btnloginform"){
            let username = (document.getElementById("username").value);
            let password = (document.getElementById("password").value);
            let url = "functions/functions.php";
            const user = {cmd: "login", username: username, password: password};
            $.ajax({
                type: "POST",
                url: url,
                data: user,
                success: function(response)
                {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == "1")
                    {
                        // console.log(jsonData);
                        window.location.replace("client/index.php");
                    }
                    else
                    {
                        alert("Хэрэглэгч олдсонгүй! Нууц үг болон нэвтрэх нэрээ шалгана уу!");
                    }
                }
            });
        }
    
    }
</script>
</html>